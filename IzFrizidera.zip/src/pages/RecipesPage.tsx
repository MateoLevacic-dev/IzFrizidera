import { Filter, Search, SlidersHorizontal } from 'lucide-react'
import { useMemo, useState } from 'react'
import { RecipeCard } from '../components/RecipeCard'
import { useAppContext } from '../context/useAppContext'

const timeOptions = ['Sve', 'do 10 min', 'do 20 min', 'do 30 min', '30+ min']
const difficultyOptions = ['Sve', 'Lako', 'Srednje', 'Teško']
const matchOptions = ['sve', '1 sastojak', '2 sastojka', 'svejedno']
const equipmentOptions = ['Sve', 'Tava', 'Pećnica', 'Blender', 'Lonac', 'Air fryer']

export const RecipesPage = () => {
  const { recipes, favoriteIds, settings, toggleFavorite, getRecipeMatch, addMissingIngredientsToShoppingList } = useAppContext()
  const [search, setSearch] = useState('')
  const [timeFilter, setTimeFilter] = useState('Sve')
  const [difficultyFilter, setDifficultyFilter] = useState('Sve')
  const [matchFilter, setMatchFilter] = useState('svejedno')
  const [equipmentFilter, setEquipmentFilter] = useState('Sve')

  const filteredRecipes = useMemo(() => {
    return [...recipes]
      .map((recipe) => ({ recipe, match: getRecipeMatch(recipe) }))
      .filter(({ recipe, match }) => {
        const matchText = search.toLowerCase()
        const includesSearch = !matchText || recipe.name.toLowerCase().includes(matchText) || recipe.description.toLowerCase().includes(matchText)
        const matchesTime = timeFilter === 'Sve' || (timeFilter === 'do 10 min' && recipe.time <= 10) || (timeFilter === 'do 20 min' && recipe.time <= 20) || (timeFilter === 'do 30 min' && recipe.time <= 30) || (timeFilter === '30+ min' && recipe.time > 30)
        const matchesDifficulty = difficultyFilter === 'Sve' || recipe.difficulty === difficultyFilter
        const sameEquipment = equipmentFilter === 'Sve' || recipe.equipment.some((item) => item.toLowerCase() === equipmentFilter.toLowerCase())
        const allergyBlocked = settings.allergies.some((allergy) => recipe.allergens.includes(allergy))
        const preferenceBlocked = settings.preferences.includes('vegansko') && !recipe.isVegan
        const safeFromPreferences = !allergyBlocked && !preferenceBlocked

        let matchStatus = true
        if (matchFilter === '1 sastojak') matchStatus = match.missing.length <= 1
        if (matchFilter === '2 sastojka') matchStatus = match.missing.length <= 2
        if (matchFilter === 'sve') matchStatus = match.missing.length === 0

        return includesSearch && matchesTime && matchesDifficulty && sameEquipment && safeFromPreferences && matchStatus
      })
      .sort((a, b) => b.match.score - a.match.score)
      .map(({ recipe, match }) => ({ recipe, match: match.score, missingCount: match.missing.length }))
  }, [recipes, search, timeFilter, difficultyFilter, matchFilter, equipmentFilter, settings, getRecipeMatch])

  return (
    <div className="space-y-5 pb-20 md:pb-8">
      <div className="rounded-[30px] border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-700 dark:bg-slate-800 md:p-5">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <p className="text-sm font-medium uppercase tracking-[0.18em] text-emerald-600">Recepti</p>
            <h1 className="mt-1 text-3xl font-bold text-slate-900 dark:text-white">Pretraži recepte</h1>
          </div>
        </div>

        <div className="mt-5 grid gap-3 md:grid-cols-[1.5fr_repeat(3,minmax(0,1fr))]">
          <label className="flex items-center gap-2 rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 dark:border-slate-600 dark:bg-slate-700">
            <Search className="h-4 w-4 text-slate-500" />
            <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Pretraži recepte" className="w-full bg-transparent text-sm text-slate-700 outline-none placeholder:text-slate-400 dark:text-white" />
          </label>

          <select value={timeFilter} onChange={(event) => setTimeFilter(event.target.value)} className="rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm text-slate-700 outline-none dark:border-slate-600 dark:bg-slate-700 dark:text-white">
            {timeOptions.map((option) => <option key={option} value={option}>{option}</option>)}
          </select>

          <select value={difficultyFilter} onChange={(event) => setDifficultyFilter(event.target.value)} className="rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm text-slate-700 outline-none dark:border-slate-600 dark:bg-slate-700 dark:text-white">
            {difficultyOptions.map((option) => <option key={option} value={option}>{option}</option>)}
          </select>

          <select value={matchFilter} onChange={(event) => setMatchFilter(event.target.value)} className="rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm text-slate-700 outline-none dark:border-slate-600 dark:bg-slate-700 dark:text-white">
            {matchOptions.map((option) => <option key={option} value={option}>{option === 'sve' ? 'Sve imam' : option === '1 sastojak' ? 'Nedostaje 1 sastojak' : option === '2 sastojka' ? 'Nedostaje 2 sastojka' : 'Svejedno'}</option>)}
          </select>
        </div>

        <div className="mt-3 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <div className="flex flex-wrap items-center gap-2 text-sm text-slate-600 dark:text-slate-300">
            <Filter className="h-4 w-4" />
            <span>Oprema:</span>
            <select value={equipmentFilter} onChange={(event) => setEquipmentFilter(event.target.value)} className="rounded-full border border-slate-200 bg-slate-50 px-3 py-1.5 text-sm outline-none dark:border-slate-600 dark:bg-slate-700 dark:text-white">
              {equipmentOptions.map((option) => <option key={option} value={option}>{option}</option>)}
            </select>
          </div>

          <div className="inline-flex items-center gap-2 rounded-full bg-emerald-50 px-3 py-1.5 text-sm font-medium text-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-200">
            <SlidersHorizontal className="h-4 w-4" />
            {filteredRecipes.length} recepta
          </div>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {filteredRecipes.length > 0 ? filteredRecipes.map(({ recipe, match, missingCount }) => (
          <RecipeCard key={recipe.id} recipe={recipe} matchScore={match} missingCount={missingCount} isFavorite={favoriteIds.includes(recipe.id)} onToggleFavorite={toggleFavorite} onAddMissing={(item) => {
            addMissingIngredientsToShoppingList(item)
          }} />
        )) : (
          <div className="col-span-full rounded-[28px] border border-dashed border-slate-300 bg-white p-8 text-center dark:border-slate-600 dark:bg-slate-800">
            <p className="text-xl font-semibold text-slate-900 dark:text-white">Nema recepta koji odgovara filterima</p>
            <p className="mt-2 text-slate-600 dark:text-slate-300">Pokušajte smanjiti kriterije ili dodati više namirnica.</p>
          </div>
        )}
      </div>
    </div>
  )
}
