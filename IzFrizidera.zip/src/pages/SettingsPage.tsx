import { MoonStar, RefreshCcw, SunMedium } from 'lucide-react'
import { useState } from 'react'
import { defaultSettings } from '../data/demoData'
import { useAppContext } from '../context/useAppContext'
import type { Allergy, Preference } from '../types'

const preferences: Preference[] = ['vegetarijansko', 'bez glutena', 'bez laktoze', 'vegansko']
const allergies: Allergy[] = ['kikiriki', 'orašasti plodovi', 'mlijeko', 'jaja', 'gluten', 'soja', 'riba', 'školjke']

export const SettingsPage = () => {
  const { settings, setSettings, setTheme, resetAppData } = useAppContext()
  const [form, setForm] = useState(settings)

  const togglePreference = (preference: Preference) => {
    setForm((current) => ({
      ...current,
      preferences: current.preferences.includes(preference) ? current.preferences.filter((item) => item !== preference) : [...current.preferences, preference]
    }))
  }

  const toggleAllergy = (allergy: Allergy) => {
    setForm((current) => ({
      ...current,
      allergies: current.allergies.includes(allergy) ? current.allergies.filter((item) => item !== allergy) : [...current.allergies, allergy]
    }))
  }

  const saveSettings = () => {
    setSettings(form)
  }

  const resetData = () => {
    resetAppData()
    setForm(defaultSettings)
  }

  return (
    <div className="space-y-5 pb-20 md:pb-8">
      <div className="rounded-[30px] border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-700 dark:bg-slate-800 md:p-5">
        <div>
          <p className="text-sm font-medium uppercase tracking-[0.18em] text-amber-600">Postavke</p>
          <h1 className="mt-1 text-3xl font-bold text-slate-900 dark:text-white">Postavke korisnika</h1>
        </div>

        <div className="mt-5 space-y-5">
          <label className="block">
            <span className="mb-1 block text-sm font-medium text-slate-700 dark:text-slate-200">Ime korisnika</span>
            <input value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 outline-none focus:border-emerald-500 dark:border-slate-600 dark:bg-slate-700 dark:text-white" />
          </label>

          <label className="block">
            <span className="mb-1 block text-sm font-medium text-slate-700 dark:text-slate-200">Broj osoba</span>
            <input type="number" min={1} value={form.servings} onChange={(event) => setForm({ ...form, servings: Number(event.target.value) || 1 })} className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 outline-none focus:border-emerald-500 dark:border-slate-600 dark:bg-slate-700 dark:text-white" />
          </label>

          <div>
            <p className="mb-2 text-sm font-medium text-slate-700 dark:text-slate-200">Prehrambene preference</p>
            <div className="flex flex-wrap gap-2">
              {preferences.map((preference) => {
                const selected = form.preferences.includes(preference)
                return (
                  <button key={preference} type="button" onClick={() => togglePreference(preference)} className={`rounded-full border px-3 py-2 text-sm font-medium ${selected ? 'border-emerald-500 bg-emerald-50 text-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-200' : 'border-slate-200 bg-white text-slate-600 dark:border-slate-600 dark:bg-slate-700 dark:text-slate-200'}`}>
                    {preference}
                  </button>
                )
              })}
            </div>
          </div>

          <div>
            <p className="mb-2 text-sm font-medium text-slate-700 dark:text-slate-200">Alergije</p>
            <div className="flex flex-wrap gap-2">
              {allergies.map((allergy) => {
                const selected = form.allergies.includes(allergy)
                return (
                  <button key={allergy} type="button" onClick={() => toggleAllergy(allergy)} className={`rounded-full border px-3 py-2 text-sm font-medium ${selected ? 'border-red-500 bg-red-50 text-red-700 dark:bg-red-950/30 dark:text-red-200' : 'border-slate-200 bg-white text-slate-600 dark:border-slate-600 dark:bg-slate-700 dark:text-slate-200'}`}>
                    {allergy}
                  </button>
                )
              })}
            </div>
          </div>

          <div>
            <p className="mb-2 text-sm font-medium text-slate-700 dark:text-slate-200">Tema</p>
            <div className="flex gap-3">
              <button type="button" onClick={() => { setForm({ ...form, theme: 'light' }); setTheme('light') }} className={`inline-flex items-center gap-2 rounded-full border px-3 py-2 text-sm font-medium ${form.theme === 'light' ? 'border-amber-500 bg-amber-50 text-amber-700 dark:border-amber-500 dark:bg-amber-950/30 dark:text-amber-200' : 'border-slate-200 bg-white text-slate-600 dark:border-slate-600 dark:bg-slate-700 dark:text-slate-200'}`}>
                <SunMedium className="h-4 w-4" /> Svijetli
              </button>
              <button type="button" onClick={() => { setForm({ ...form, theme: 'dark' }); setTheme('dark') }} className={`inline-flex items-center gap-2 rounded-full border px-3 py-2 text-sm font-medium ${form.theme === 'dark' ? 'border-indigo-500 bg-indigo-50 text-indigo-700 dark:border-indigo-500 dark:bg-indigo-950/30 dark:text-indigo-200' : 'border-slate-200 bg-white text-slate-600 dark:border-slate-600 dark:bg-slate-700 dark:text-slate-200'}`}>
                <MoonStar className="h-4 w-4" /> Tamni
              </button>
            </div>
          </div>

          <div className="flex flex-col gap-3 pt-3 sm:flex-row">
            <button type="button" onClick={saveSettings} className="rounded-full bg-emerald-500 px-4 py-2.5 text-sm font-semibold text-white hover:bg-emerald-600">
              Spremi postavke
            </button>
            <button type="button" onClick={resetData} className="inline-flex items-center gap-2 rounded-full border border-red-200 bg-red-50 px-4 py-2.5 text-sm font-semibold text-red-700 hover:bg-red-100 dark:border-red-900 dark:bg-red-950/20 dark:text-red-200">
              <RefreshCcw className="h-4 w-4" /> Reset podataka
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
