import { Pencil, Plus, Search, Trash2 } from 'lucide-react'
import { useMemo, useState } from 'react'
import { IngredientFormModal } from '../components/IngredientFormModal'
import { useAppContext } from '../context/useAppContext'
import type { Ingredient } from '../types'

export const IngredientsPage = () => {
  const { ingredients, addIngredient, updateIngredient, deleteIngredient, getExpiryStatus } = useAppContext()
  const [search, setSearch] = useState('')
  const [selectedLocation, setSelectedLocation] = useState('Sve')
  const [sortBy, setSortBy] = useState<'naziv' | 'rok' | 'kategorija'>('rok')
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [editingIngredient, setEditingIngredient] = useState<Ingredient | undefined>()

  const filteredIngredients = useMemo(() => {
    const query = search.toLowerCase()
    const next = ingredients.filter((item) => {
      const matchesSearch = !query || item.name.toLowerCase().includes(query) || item.category.toLowerCase().includes(query)
      const matchesLocation = selectedLocation === 'Sve' || item.location === selectedLocation
      return matchesSearch && matchesLocation
    })

    return next.sort((a, b) => {
      if (sortBy === 'naziv') return a.name.localeCompare(b.name)
      if (sortBy === 'kategorija') return a.category.localeCompare(b.category)
      return new Date(a.expiryDate).getTime() - new Date(b.expiryDate).getTime()
    })
  }, [ingredients, search, selectedLocation, sortBy])

  const handleSave = (ingredient: Omit<Ingredient, 'id'>) => {
    if (editingIngredient) {
      updateIngredient(editingIngredient.id, ingredient)
    } else {
      addIngredient(ingredient)
    }
    setEditingIngredient(undefined)
  }

  const handleQuantity = (id: string, delta: number) => {
    const current = ingredients.find((ingredient) => ingredient.id === id)
    if (!current) return
    updateIngredient(id, { quantity: Math.max(0, current.quantity + delta) })
  }

  return (
    <div className="space-y-5 pb-20 md:pb-8">
      <div className="rounded-[30px] border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-700 dark:bg-slate-800 md:p-5">
        <div className="relative flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div className="text-center md:flex-1">
            <p className="text-sm font-medium uppercase tracking-[0.18em] text-emerald-600">Fridge</p>
            <h1 className="mt-1 text-3xl font-bold text-slate-900 dark:text-white">Moje namirnice</h1>
          </div>
          <button type="button" onClick={() => setIsModalOpen(true)} className="inline-flex items-center justify-center gap-2 rounded-full bg-emerald-500 px-4 py-2.5 text-sm font-semibold text-white hover:bg-emerald-600">
            <Plus className="h-4 w-4" /> Dodaj namirnicu
          </button>
        </div>

        <div className="mt-5 grid gap-3 md:grid-cols-[1.3fr_0.7fr_0.7fr]">
          <label className="flex items-center gap-2 rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 dark:border-slate-600 dark:bg-slate-700">
            <Search className="h-4 w-4 text-slate-500" />
            <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Pretraži namirnice" className="w-full bg-transparent text-sm text-slate-700 outline-none placeholder:text-slate-400 dark:text-white" />
          </label>

          <select value={selectedLocation} onChange={(event) => setSelectedLocation(event.target.value)} className="rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm text-slate-700 outline-none dark:border-slate-600 dark:bg-slate-700 dark:text-white">
            <option value="Sve">Sve lokacije</option>
            <option value="Hladnjak">Hladnjak</option>
            <option value="Zamrzivač">Zamrzivač</option>
            <option value="Smočnica">Smočnica</option>
          </select>

          <select value={sortBy} onChange={(event) => setSortBy(event.target.value as 'naziv' | 'rok' | 'kategorija')} className="rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm text-slate-700 outline-none dark:border-slate-600 dark:bg-slate-700 dark:text-white">
            <option value="rok">Sortiraj po roku</option>
            <option value="naziv">Naziv</option>
            <option value="kategorija">Kategorija</option>
          </select>
        </div>
      </div>

      {filteredIngredients.length === 0 ? (
        <div className="rounded-[28px] border border-dashed border-slate-300 bg-white p-10 text-center shadow-sm dark:border-slate-600 dark:bg-slate-800">
          <p className="text-xl font-semibold text-slate-900 dark:text-white">Frižider je prazan 😅</p>
          <p className="mt-2 text-slate-600 dark:text-slate-300">Dodaj svoje prve namirnice i pronaći ćemo što možeš skuhati.</p>
          <button type="button" onClick={() => setIsModalOpen(true)} className="mt-5 rounded-full bg-emerald-500 px-4 py-2.5 text-sm font-semibold text-white hover:bg-emerald-600">
            + Dodaj namirnicu
          </button>
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {filteredIngredients.map((ingredient) => {
            const status = getExpiryStatus(ingredient)
            const statusClasses = {
              svježe: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-200',
              'uskoro istječe': 'bg-amber-100 text-amber-700 dark:bg-amber-950/30 dark:text-amber-200',
              isteklo: 'bg-red-100 text-red-700 dark:bg-red-950/30 dark:text-red-200'
            }

            return (
              <article key={ingredient.id} className="overflow-hidden rounded-[28px] border border-slate-200 bg-white shadow-sm dark:border-slate-700 dark:bg-slate-800">
                <div className="relative h-36 w-full overflow-hidden">
                  <img src={ingredient.image || 'https://images.unsplash.com/photo-1546094096-0df4bcaaa337?auto=format&fit=crop&w=900&q=80'} alt={ingredient.name} className="h-full w-full object-cover" onError={(event) => { event.currentTarget.src = 'https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=900&q=80' }} />
                  <span className={`absolute left-3 top-3 rounded-full px-2 py-1 text-[10px] font-semibold uppercase tracking-[0.15em] ${statusClasses[status]}`}>
                    {status}
                  </span>
                </div>

                <div className="space-y-4 p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 text-center">
                      <h3 className="text-xl font-bold text-slate-900 dark:text-white">{ingredient.name}</h3>
                      <p className="text-sm text-slate-500 dark:text-slate-300">{ingredient.category}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button type="button" onClick={() => { setEditingIngredient(ingredient); setIsModalOpen(true) }} className="rounded-full border border-slate-200 p-2 text-slate-600 hover:bg-slate-100 dark:border-slate-600 dark:text-slate-200 dark:hover:bg-slate-700">
                        <Pencil className="h-4 w-4" />
                      </button>
                      <button type="button" onClick={() => deleteIngredient(ingredient.id)} className="rounded-full border border-red-200 p-2 text-red-600 hover:bg-red-50 dark:border-red-800 dark:text-red-200 dark:hover:bg-red-950/30">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center justify-between gap-3 rounded-2xl bg-slate-50 p-3 dark:bg-slate-700/50">
                    <div>
                      <p className="text-xs uppercase tracking-[0.18em] text-slate-500 dark:text-slate-300">Količina</p>
                      <p className="mt-1 text-lg font-semibold text-slate-900 dark:text-white">{ingredient.quantity} {ingredient.unit}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button type="button" onClick={() => handleQuantity(ingredient.id, -1)} className="flex h-8 w-8 items-center justify-center rounded-full border border-slate-200 text-lg dark:border-slate-600 dark:text-white">−</button>
                      <button type="button" onClick={() => handleQuantity(ingredient.id, 1)} className="flex h-8 w-8 items-center justify-center rounded-full border border-slate-200 text-lg dark:border-slate-600 dark:text-white">＋</button>
                    </div>
                  </div>

                  <div className="grid gap-2 text-sm text-slate-600 dark:text-slate-300">
                    <p><span className="font-medium text-slate-800 dark:text-white">Dodano:</span> {ingredient.addedDate}</p>
                    <p><span className="font-medium text-slate-800 dark:text-white">Rok:</span> {ingredient.expiryDate}</p>
                    <p><span className="font-medium text-slate-800 dark:text-white">Lokacija:</span> {ingredient.location}</p>
                  </div>
                </div>
              </article>
            )
          })}
        </div>
      )}

      <IngredientFormModal key={`${isModalOpen ? 'open' : 'closed'}-${editingIngredient?.id ?? 'new'}`} isOpen={isModalOpen} ingredient={editingIngredient} onClose={() => { setIsModalOpen(false); setEditingIngredient(undefined) }} onSave={handleSave} />
    </div>
  )
}
