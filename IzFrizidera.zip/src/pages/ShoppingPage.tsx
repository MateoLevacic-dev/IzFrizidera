import { Check, Plus, Search, Trash2 } from 'lucide-react'
import { useMemo, useState } from 'react'
import { useAppContext } from '../context/useAppContext'

const categories = ['Sve', 'Mlječni proizvodi', 'Jaja', 'Povrće', 'Žitarice', 'Ostalo']

export const ShoppingPage = () => {
  const { shoppingList, addShoppingItem, toggleShoppingItem, deleteShoppingItem, updateShoppingItem } = useAppContext()
  const [name, setName] = useState('')
  const [quantity, setQuantity] = useState(1)
  const [category, setCategory] = useState('Ostalo')
  const [unit, setUnit] = useState('kom')
  const [search, setSearch] = useState('')
  const [filter, setFilter] = useState('Sve')

  const visibleList = useMemo(() => {
    return shoppingList.filter((item) => {
      const matchesSearch = !search || item.name.toLowerCase().includes(search.toLowerCase())
      const matchesFilter = filter === 'Sve' || item.category === filter
      return matchesSearch && matchesFilter
    })
  }, [shoppingList, search, filter])

  const handleSubmit = () => {
    if (!name.trim()) return
    addShoppingItem({ name: name.trim(), category, quantity, unit, checked: false })
    setName('')
    setQuantity(1)
    setCategory('Ostalo')
    setUnit('kom')
  }

  return (
    <div className="space-y-5 pb-20 md:pb-8">
      <div className="rounded-[30px] border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-700 dark:bg-slate-800 md:p-5">
        <div className="flex items-center justify-between gap-3">
          <div>
            <p className="text-sm font-medium uppercase tracking-[0.18em] text-emerald-600">Kupovina</p>
            <h1 className="mt-1 text-3xl font-bold text-slate-900 dark:text-white">Shopping lista</h1>
          </div>
        </div>

        <div className="mt-5 grid gap-3 md:grid-cols-[1.2fr_0.5fr_0.5fr_0.7fr]">
          <input value={name} onChange={(event) => setName(event.target.value)} placeholder="Naziv proizvoda" className="rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-emerald-500 dark:border-slate-600 dark:bg-slate-700 dark:text-white" />
          <input type="number" min={1} value={quantity} onChange={(event) => setQuantity(Number(event.target.value) || 1)} className="rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-emerald-500 dark:border-slate-600 dark:bg-slate-700 dark:text-white" />
          <input value={unit} onChange={(event) => setUnit(event.target.value)} placeholder="kom" className="rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none focus:border-emerald-500 dark:border-slate-600 dark:bg-slate-700 dark:text-white" />
          <select value={category} onChange={(event) => setCategory(event.target.value)} className="rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm outline-none dark:border-slate-600 dark:bg-slate-700 dark:text-white">
            {categories.filter((item) => item !== 'Sve').map((item) => <option key={item} value={item}>{item}</option>)}
          </select>
        </div>

        <div className="mt-3 flex items-center justify-end">
          <button type="button" onClick={handleSubmit} className="inline-flex items-center gap-2 rounded-full bg-emerald-500 px-4 py-2.5 text-sm font-semibold text-white hover:bg-emerald-600">
            <Plus className="h-4 w-4" /> Dodaj proizvod
          </button>
        </div>
      </div>

      <div className="rounded-[30px] border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-700 dark:bg-slate-800 md:p-5">
        <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <label className="flex w-full max-w-md items-center gap-2 rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 dark:border-slate-600 dark:bg-slate-700">
            <Search className="h-4 w-4 text-slate-500" />
            <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Pretraži listu" className="w-full bg-transparent text-sm text-slate-700 outline-none placeholder:text-slate-400 dark:text-white" />
          </label>

          <select value={filter} onChange={(event) => setFilter(event.target.value)} className="rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm text-slate-700 outline-none dark:border-slate-600 dark:bg-slate-700 dark:text-white">
            {categories.map((item) => <option key={item} value={item}>{item}</option>)}
          </select>
        </div>

        <div className="mt-5 space-y-3">
          {visibleList.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-slate-300 p-8 text-center dark:border-slate-600">
              <p className="text-xl font-semibold text-slate-900 dark:text-white">Nema proizvoda na listi</p>
              <p className="mt-2 text-slate-600 dark:text-slate-300">Dodajte prvi proizvod za svoju kupovinu.</p>
            </div>
          ) : visibleList.map((item) => (
            <div key={item.id} className={`flex items-center justify-between gap-3 rounded-2xl border p-3 ${item.checked ? 'border-emerald-200 bg-emerald-50 dark:border-emerald-900 dark:bg-emerald-950/20' : 'border-slate-200 bg-slate-50 dark:border-slate-600 dark:bg-slate-700/50'}`}>
              <button type="button" onClick={() => toggleShoppingItem(item.id)} className={`flex h-5 w-5 items-center justify-center rounded-full border ${item.checked ? 'border-emerald-500 bg-emerald-500 text-white' : 'border-slate-300 dark:border-slate-500'}`}>
                {item.checked && <Check className="h-3 w-3" />}
              </button>

              <div className="flex-1 min-w-0">
                <p className={`truncate font-semibold ${item.checked ? 'text-slate-500 line-through dark:text-slate-400' : 'text-slate-900 dark:text-white'}`}>{item.name}</p>
                <p className="text-sm text-slate-500 dark:text-slate-300">{item.quantity} {item.unit} · {item.category}</p>
              </div>

              <div className="flex items-center gap-2">
                <button type="button" onClick={() => updateShoppingItem(item.id, { quantity: Math.max(1, item.quantity - 1) })} className="flex h-8 w-8 items-center justify-center rounded-full border border-slate-200 dark:border-slate-600 dark:text-white">−</button>
                <button type="button" onClick={() => updateShoppingItem(item.id, { quantity: item.quantity + 1 })} className="flex h-8 w-8 items-center justify-center rounded-full border border-slate-200 dark:border-slate-600 dark:text-white">＋</button>
                <button type="button" onClick={() => deleteShoppingItem(item.id)} className="rounded-full border border-red-200 p-2 text-red-600 hover:bg-red-50 dark:border-red-800 dark:text-red-200 dark:hover:bg-red-950/30">
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
