import { ChefHat, Eye, EyeOff, LockKeyhole, Mail, UserRound } from 'lucide-react'
import { useState, type FormEvent } from 'react'
import { apiRequest } from '../lib/api'
import type { AuthUser } from '../types'

interface AuthPageProps {
  onAuthenticated: (user: AuthUser) => Promise<void>
  initialError?: string
}

export const AuthPage = ({ onAuthenticated, initialError = '' }: AuthPageProps) => {
  const [mode, setMode] = useState<'login' | 'register'>('login')
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [remember, setRemember] = useState(true)
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState(initialError)
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    setError('')
    setLoading(true)
    try {
      const endpoint = mode === 'login' ? '/api/auth/login' : '/api/auth/register'
      const result = await apiRequest<{ user: AuthUser }>(endpoint, {
        method: 'POST',
        body: JSON.stringify({ name, email, password, remember })
      })
      await onAuthenticated(result.user)
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : 'Prijava nije uspjela.')
    } finally {
      setLoading(false)
    }
  }

  const changeMode = (nextMode: 'login' | 'register') => {
    setMode(nextMode)
    setError('')
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-slate-100 px-4 py-8 dark:bg-slate-950">
      <div className="grid w-full max-w-5xl overflow-hidden rounded-[28px] border border-slate-200 bg-white shadow-2xl dark:border-slate-700 dark:bg-slate-900 md:min-h-[590px] md:grid-cols-[0.9fr_1.1fr]">
        <section className="flex flex-col justify-between bg-emerald-800 p-7 text-white md:p-10">
          <div className="flex items-center gap-3">
            <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-white/15"><ChefHat className="h-6 w-6" /></span>
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.18em] text-emerald-100">IzFrižidera</p>
              <p className="font-semibold">Pametna kuhinja</p>
            </div>
          </div>
          <div className="py-8 md:py-0">
            <p className="text-sm font-semibold uppercase tracking-[0.18em] text-emerald-200">Dobro došli</p>
            <h1 className="mt-3 max-w-sm text-3xl font-bold leading-tight md:text-4xl">Sve tvoje namirnice, recepti i planovi na jednom mjestu.</h1>
            <p className="mt-4 max-w-sm text-sm leading-6 text-emerald-100">Prijavi se za pristup svojoj spremljenoj kuhinji.</p>
          </div>
          <p className="text-xs text-emerald-200">Podaci računa i kuhinje spremaju se lokalno u SQLite bazu.</p>
        </section>

        <section className="flex items-center justify-center p-6 md:p-10">
          <div className="w-full max-w-md">
            <div className="mb-7">
              <h2 className="text-2xl font-bold text-slate-900 dark:text-white">{mode === 'login' ? 'Prijava' : 'Napravi račun'}</h2>
              <p className="mt-1 text-sm text-slate-500 dark:text-slate-300">{mode === 'login' ? 'Nastavi tamo gdje si stao.' : 'Tvoj osobni prostor za planiranje obroka.'}</p>
            </div>

            <div className="mb-6 grid grid-cols-2 rounded-xl bg-slate-100 p-1 dark:bg-slate-800" role="tablist" aria-label="Način prijave">
              <button type="button" role="tab" aria-selected={mode === 'login'} onClick={() => changeMode('login')} className={`rounded-lg px-3 py-2 text-sm font-semibold transition ${mode === 'login' ? 'bg-white text-slate-900 shadow-sm dark:bg-slate-700 dark:text-white' : 'text-slate-500 dark:text-slate-300'}`}>Prijava</button>
              <button type="button" role="tab" aria-selected={mode === 'register'} onClick={() => changeMode('register')} className={`rounded-lg px-3 py-2 text-sm font-semibold transition ${mode === 'register' ? 'bg-white text-slate-900 shadow-sm dark:bg-slate-700 dark:text-white' : 'text-slate-500 dark:text-slate-300'}`}>Registracija</button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              {mode === 'register' && (
                <label className="block">
                  <span className="mb-1.5 block text-sm font-medium text-slate-700 dark:text-slate-200">Ime</span>
                  <span className="flex items-center gap-2 rounded-xl border border-slate-300 px-3 focus-within:border-emerald-600 dark:border-slate-600 dark:bg-slate-800">
                    <UserRound className="h-4 w-4 text-slate-400" />
                    <input required minLength={2} maxLength={80} autoComplete="name" value={name} onChange={(event) => setName(event.target.value)} className="w-full bg-transparent py-3 text-sm outline-none dark:text-white" placeholder="Tvoje ime" />
                  </span>
                </label>
              )}

              <label className="block">
                <span className="mb-1.5 block text-sm font-medium text-slate-700 dark:text-slate-200">E-mail</span>
                <span className="flex items-center gap-2 rounded-xl border border-slate-300 px-3 focus-within:border-emerald-600 dark:border-slate-600 dark:bg-slate-800">
                  <Mail className="h-4 w-4 text-slate-400" />
                  <input required type="email" autoComplete="email" value={email} onChange={(event) => setEmail(event.target.value)} className="w-full bg-transparent py-3 text-sm outline-none dark:text-white" placeholder="ime@primjer.hr" />
                </span>
              </label>

              <label className="block">
                <span className="mb-1.5 block text-sm font-medium text-slate-700 dark:text-slate-200">Lozinka</span>
                <span className="flex items-center gap-2 rounded-xl border border-slate-300 px-3 focus-within:border-emerald-600 dark:border-slate-600 dark:bg-slate-800">
                  <LockKeyhole className="h-4 w-4 text-slate-400" />
                  <input required minLength={mode === 'register' ? 8 : undefined} autoComplete={mode === 'login' ? 'current-password' : 'new-password'} type={showPassword ? 'text' : 'password'} value={password} onChange={(event) => setPassword(event.target.value)} className="w-full bg-transparent py-3 text-sm outline-none dark:text-white" placeholder={mode === 'register' ? 'Najmanje 8 znakova' : 'Unesi lozinku'} />
                  <button type="button" onClick={() => setShowPassword((visible) => !visible)} className="rounded p-1 text-slate-500 hover:text-slate-800 dark:hover:text-white" aria-label={showPassword ? 'Sakrij lozinku' : 'Prikaži lozinku'}>
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </span>
              </label>

              <label className="flex items-center gap-2 py-1 text-sm text-slate-600 dark:text-slate-300">
                <input type="checkbox" checked={remember} onChange={(event) => setRemember(event.target.checked)} className="h-4 w-4 accent-emerald-600" />
                Ostani prijavljen
              </label>

              {error && <p role="alert" className="rounded-xl border border-red-200 bg-red-50 px-3 py-2.5 text-sm text-red-700 dark:border-red-900 dark:bg-red-950/30 dark:text-red-200">{error}</p>}

              <button type="submit" disabled={loading} className="w-full rounded-xl bg-emerald-700 px-4 py-3 font-semibold text-white transition hover:bg-emerald-800 disabled:cursor-wait disabled:opacity-60">
                {loading ? 'Molim pričekaj...' : mode === 'login' ? 'Prijavi se' : 'Napravi račun'}
              </button>
            </form>
          </div>
        </section>
      </div>
    </main>
  )
}