import { Camera, ChevronRight, Heart, Search, ShoppingBasket, Sparkles, UtensilsCrossed } from 'lucide-react'
import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { AIChatModal } from '../components/AIChatModal'
import { IngredientFormModal } from '../components/IngredientFormModal'
import { ScanModal } from '../components/ScanModal'
import { RecipeCard } from '../components/RecipeCard'
import { useAppContext } from '../context/useAppContext'

export const HomePage = () => {
  const { ingredients, recipes, favoriteIds, toggleFavorite, getRecipeMatch, getExpiryStatus, addIngredient, addMissingIngredientsToShoppingList, appendChatMessage, chatMessages } = useAppContext()
  const [search, setSearch] = useState('')
  const [scanOpen, setScanOpen] = useState(false)
  const [chatOpen, setChatOpen] = useState(false)
  const [ingredientFormOpen, setIngredientFormOpen] = useState(false)

  const recommended = useMemo(() => {
    return [...recipes]
      .map((recipe) => ({ recipe, match: getRecipeMatch(recipe) }))
      .filter(({ recipe }) => !search.trim() || recipe.name.toLowerCase().includes(search.trim().toLowerCase()) || recipe.description.toLowerCase().includes(search.trim().toLowerCase()) || recipe.ingredients.some((item) => item.name.toLowerCase().includes(search.trim().toLowerCase())))
      .filter(({ match }) => match.score >= 25)
      .sort((a, b) => b.match.score - a.match.score)
      .slice(0, 4)
  }, [recipes, search, getRecipeMatch])

  const expiringSoon = useMemo(() => {
    return [...ingredients]
      .filter((item) => getExpiryStatus(item) !== 'svježe')
      .sort((a, b) => new Date(a.expiryDate).getTime() - new Date(b.expiryDate).getTime())
      .slice(0, 4)
  }, [ingredients, getExpiryStatus])

  const handleScanConfirm = (items: string[]) => {
    items.forEach((item) => {
      const existing = ingredients.some((ingredient) => ingredient.name.toLowerCase() === item.toLowerCase())
      if (!existing) {
        addIngredient({
          name: item,
          category: 'Ostalo',
          quantity: 1,
          unit: 'kom',
          addedDate: new Date().toISOString().slice(0, 10),
          expiryDate: new Date(Date.now() + 86400000 * 5).toISOString().slice(0, 10),
          location: 'Hladnjak',
          image: 'https://images.unsplash.com/photo-1546094096-0df4bcaaa337?auto=format&fit=crop&w=900&q=80'
        })
      }
    })
    setScanOpen(false)
  }

  const handleAIMessage = (text: string) => {
    appendChatMessage({ id: crypto.randomUUID(), sender: 'user', text })

    const message = text.toLowerCase()
    let response = 'Možeš napraviti brz i zdrav obrok s namirnicama koje trenutno imaš.'

    if (message.includes('mlijeko')) response = 'Ako ti nedostaje mlijeko, možeš ga zamijeniti s biljnim napitkom ili jogurtom u umaku.'
    if (message.includes('pećnici') || message.includes('bez pećnice')) response = 'U ovom slučaju preporučujem omeletu, sendvič, tjesteninu ili rižoto na tavi.'
    if (message.includes('što mogu')) response = 'Najprikladniji recepti su omeleta, tost pizza i salata s piletinom.'

    appendChatMessage({ id: crypto.randomUUID(), sender: 'assistant', text: response })
  }

  const heroRecipes = recommended.filter(({ match }) => match.score > 50).slice(0, 2)

  return (
    <div className="space-y-6 pb-20 md:pb-8">
      <header className="rounded-[30px] bg-gradient-to-br from-emerald-500 via-emerald-600 to-teal-700 p-5 text-white shadow-xl md:p-7">
        <div className="flex items-center justify-between gap-4">
          <div>
            <p className="text-sm font-medium uppercase tracking-[0.18em] text-emerald-100">IzFrižidera</p>
            <h1 className="mt-2 text-3xl font-bold md:text-4xl">Pozdrav! 👋</h1>
          </div>
          <button type="button" onClick={() => setChatOpen(true)} className="rounded-full border border-white/30 bg-white/10 px-3 py-2 text-sm font-medium backdrop-blur-sm">
            Chef AI
          </button>
        </div>

        <p className="mt-2 text-lg text-emerald-50">Što danas kuhamo?</p>

        <div className="mt-5 flex items-center gap-3 rounded-2xl bg-white/10 p-3 backdrop-blur-sm">
          <Search className="h-5 w-5 text-emerald-100" />
          <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Što imaš u hladnjaku?" className="w-full bg-transparent text-sm text-white placeholder:text-emerald-50/80 outline-none" />
        </div>

        <div className="mt-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
          <button type="button" onClick={() => setIngredientFormOpen(true)} className="rounded-2xl bg-white/12 p-3 text-left backdrop-blur-sm transition hover:bg-white/20">
            <div className="flex items-center gap-2 text-sm font-semibold"><Camera className="h-4 w-4" /> Dodaj namirnicu</div>
          </button>
          <button type="button" onClick={() => setScanOpen(true)} className="rounded-2xl bg-white/12 p-3 text-left backdrop-blur-sm transition hover:bg-white/20">
            <div className="flex items-center gap-2 text-sm font-semibold"><Sparkles className="h-4 w-4" /> Skeniraj namirnice</div>
          </button>
          <Link to="/recipes" className="rounded-2xl bg-white/12 p-3 text-left backdrop-blur-sm transition hover:bg-white/20">
            <div className="flex items-center gap-2 text-sm font-semibold"><UtensilsCrossed className="h-4 w-4" /> Pronađi recept</div>
          </Link>
          <Link to="/shopping" className="rounded-2xl bg-white/12 p-3 text-left backdrop-blur-sm transition hover:bg-white/20">
            <div className="flex items-center gap-2 text-sm font-semibold"><ShoppingBasket className="h-4 w-4" /> Shopping lista</div>
          </Link>
        </div>
      </header>

      <section className="rounded-[28px] border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-700 dark:bg-slate-800 md:p-5">
        <div className="mb-4 flex items-center justify-between">
          <div>
            <p className="text-sm font-medium uppercase tracking-[0.18em] text-emerald-600">Predloženo</p>
            <h2 className="mt-1 text-2xl font-bold text-slate-900 dark:text-white">Predloženo za tebe</h2>
          </div>
          <Link to="/recipes" className="inline-flex items-center gap-1 text-sm font-semibold text-emerald-600">
            Vidi sve <ChevronRight className="h-4 w-4" />
          </Link>
        </div>

        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {recommended.map(({ recipe, match }) => (
            <RecipeCard key={recipe.id} recipe={recipe} matchScore={match.score} missingCount={match.missing.length} isFavorite={favoriteIds.includes(recipe.id)} onToggleFavorite={toggleFavorite} onAddMissing={addMissingIngredientsToShoppingList} />
          ))}
        </div>
      </section>

      <div className="grid gap-6 lg:grid-cols-[1.2fr_0.8fr]">
        <section className="rounded-[28px] border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-700 dark:bg-slate-800 md:p-5">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <p className="text-sm font-medium uppercase tracking-[0.18em] text-amber-600">Uskoro</p>
              <h2 className="mt-1 text-2xl font-bold text-slate-900 dark:text-white">Potroši prvo</h2>
            </div>
          </div>

          <div className="space-y-3">
            {expiringSoon.length > 0 ? expiringSoon.map((item) => (
              <div key={item.id} className="flex items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-slate-50 p-3 dark:border-slate-600 dark:bg-slate-700/50">
                <div className="flex items-center gap-3">
                  <div className={`flex h-10 w-10 items-center justify-center rounded-full ${getExpiryStatus(item) === 'isteklo' ? 'bg-red-100 text-red-600 dark:bg-red-950/30 dark:text-red-200' : 'bg-amber-100 text-amber-600 dark:bg-amber-950/30 dark:text-amber-200'}`}>
                    {getExpiryStatus(item) === 'isteklo' ? '🔴' : '🟡'}
                  </div>
                  <div>
                    <p className="font-semibold text-slate-900 dark:text-white">{item.name}</p>
                    <p className="text-sm text-slate-500 dark:text-slate-300">Rok: {item.expiryDate}</p>
                  </div>
                </div>
                <span className="text-xs font-medium uppercase tracking-[0.15em] text-slate-500 dark:text-slate-300">{getExpiryStatus(item)}</span>
              </div>
            )) : <p className="rounded-2xl bg-emerald-50 px-3 py-3 text-sm text-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-200">Sve namirnice su trenutno svježe.</p>}
          </div>
        </section>

        <section className="rounded-[28px] border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-700 dark:bg-slate-800 md:p-5">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <p className="text-sm font-medium uppercase tracking-[0.18em] text-violet-600">Što možeš</p>
              <h2 className="mt-1 text-2xl font-bold text-slate-900 dark:text-white">Možeš odmah napraviti</h2>
            </div>
          </div>

          <div className="space-y-3">
            {heroRecipes.length > 0 ? heroRecipes.map(({ recipe, match }) => (
              <Link key={recipe.id} to="/recipes" className="flex items-center justify-between rounded-2xl border border-slate-200 bg-slate-50 p-3 dark:border-slate-600 dark:bg-slate-700/50">
                <div>
                  <p className="font-semibold text-slate-900 dark:text-white">{recipe.name}</p>
                  <p className="text-sm text-slate-500 dark:text-slate-300">{match.score}% namirnica imaš</p>
                </div>
                <div className="flex items-center gap-2 text-emerald-600">
                  <Heart className="h-4 w-4" />
                  <ChevronRight className="h-4 w-4" />
                </div>
              </Link>
            )) : <p className="rounded-2xl bg-slate-100 px-3 py-3 text-sm text-slate-600 dark:bg-slate-700 dark:text-slate-200">Dodaj više namirnica za bolje preporuke.</p>}
          </div>
        </section>
      </div>

      <ScanModal key={`scan-${scanOpen ? 'open' : 'closed'}`} isOpen={scanOpen} onClose={() => setScanOpen(false)} onConfirm={handleScanConfirm} />
      <IngredientFormModal key={`ingredient-${ingredientFormOpen ? 'open' : 'closed'}`} isOpen={ingredientFormOpen} onClose={() => setIngredientFormOpen(false)} onSave={addIngredient} />
      <AIChatModal isOpen={chatOpen} onClose={() => setChatOpen(false)} messages={chatMessages} onSend={handleAIMessage} />
    </div>
  )
}
