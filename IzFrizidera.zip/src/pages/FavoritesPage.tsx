import { Heart, Search } from 'lucide-react'
import { useMemo, useState } from 'react'
import { RecipeCard } from '../components/RecipeCard'
import { useAppContext } from '../context/useAppContext'

export const FavoritesPage = () => {
  const { recipes, favoriteIds, toggleFavorite, addMissingIngredientsToShoppingList } = useAppContext()
  const [search, setSearch] = useState('')

  const favoriteRecipes = useMemo(() => {
    return recipes.filter((recipe) => favoriteIds.includes(recipe.id)).filter((recipe) => !search || recipe.name.toLowerCase().includes(search.toLowerCase()))
  }, [recipes, favoriteIds, search])

  return (
    <div className="space-y-5 pb-20 md:pb-8">
      <div className="rounded-[30px] border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-700 dark:bg-slate-800 md:p-5">
        <div className="flex items-center justify-between gap-3">
          <div>
            <p className="text-sm font-medium uppercase tracking-[0.18em] text-rose-600">Omiljeno</p>
            <h1 className="mt-1 text-3xl font-bold text-slate-900 dark:text-white">❤️ Omiljeni recepti</h1>
          </div>
        </div>

        <label className="mt-5 flex items-center gap-2 rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 dark:border-slate-600 dark:bg-slate-700">
          <Search className="h-4 w-4 text-slate-500" />
          <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Pretraži omiljene recepte" className="w-full bg-transparent text-sm text-slate-700 outline-none placeholder:text-slate-400 dark:text-white" />
        </label>
      </div>

      {favoriteRecipes.length === 0 ? (
        <div className="rounded-[28px] border border-dashed border-slate-300 bg-white p-10 text-center shadow-sm dark:border-slate-600 dark:bg-slate-800">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-rose-100 text-rose-600 dark:bg-rose-950/30 dark:text-rose-200">
            <Heart className="h-8 w-8" />
          </div>
          <p className="mt-4 text-xl font-semibold text-slate-900 dark:text-white">Nema spremljenih recepata</p>
          <p className="mt-2 text-slate-600 dark:text-slate-300">Dodajte recept u omiljeno da ostane spremljen i nakon osvježavanja.</p>
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {favoriteRecipes.map((recipe) => (
            <RecipeCard key={recipe.id} recipe={recipe} isFavorite onToggleFavorite={toggleFavorite} onAddMissing={addMissingIngredientsToShoppingList} />
          ))}
        </div>
      )}
    </div>
  )
}
