export type IngredientCategory =
  | 'Povrće'
  | 'Voće'
  | 'Meso'
  | 'Riba'
  | 'Mliječni proizvodi'
  | 'Jaja'
  | 'Žitarice'
  | 'Tjestenina'
  | 'Konzervirano'
  | 'Začini'
  | 'Pića'
  | 'Ostalo'

export type StorageLocation = 'Hladnjak' | 'Zamrzivač' | 'Smočnica'

export type Preference = 'vegetarijansko' | 'bez glutena' | 'bez laktoze' | 'vegansko'

export type Allergy =
  | 'kikiriki'
  | 'orašasti plodovi'
  | 'mlijeko'
  | 'jaja'
  | 'gluten'
  | 'soja'
  | 'riba'
  | 'školjke'

export type ExpiryStatus = 'svježe' | 'uskoro istječe' | 'isteklo'
export type Difficulty = 'Lako' | 'Srednje' | 'Teško'

export interface Ingredient {
  id: string
  name: string
  category: IngredientCategory
  quantity: number
  unit: string
  addedDate: string
  expiryDate: string
  location: StorageLocation
  image?: string
}

export interface RecipeIngredient {
  name: string
  quantity: string
  unit: string
  optional?: boolean
}

export interface Nutrition {
  calories?: number
  protein?: string
  carbs?: string
  fat?: string
  fiber?: string
}

export interface Recipe {
  id: string
  name: string
  description: string
  image: string
  time: number
  difficulty: Difficulty
  servings: number
  ingredients: RecipeIngredient[]
  steps: string[]
  equipment: string[]
  tags: string[]
  allergens: Allergy[]
  nutrition?: Nutrition
  isVegetarian?: boolean
  isGlutenFree?: boolean
  isDairyFree?: boolean
  isVegan?: boolean
}

export interface ShoppingItem {
  id: string
  name: string
  category: string
  quantity: number
  unit: string
  checked: boolean
}

export interface UserSettings {
  name: string
  preferences: Preference[]
  allergies: Allergy[]
  servings: number
  favoriteCategories: string[]
  theme: 'light' | 'dark'
  language: 'hr'
}

export interface ChatMessage {
  id: string
  sender: 'user' | 'assistant'
  text: string
}

export interface RecipeMatch {
  score: number
  missing: string[]
  available: string[]
}

export interface AuthUser {
  id: string
  name: string
  email: string
}

export interface PersistedAppData {
  ingredients: Ingredient[]
  shoppingList: ShoppingItem[]
  favoriteIds: string[]
  settings: UserSettings
  chatMessages: ChatMessage[]
}
