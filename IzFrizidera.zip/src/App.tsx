import { ChefHat, Heart, Home, ListTodo, LogOut, MoonStar, Settings, ShoppingCart, Soup, SunMedium } from 'lucide-react'
import { useEffect, useState } from 'react'
import { BrowserRouter, NavLink, Route, Routes } from 'react-router-dom'
import { BottomNav } from './components/BottomNav'
import { AppProvider } from './context/AppContext'
import { useAppContext } from './context/useAppContext'
import { apiRequest } from './lib/api'
import { AuthPage } from './pages/AuthPage'
import { FavoritesPage } from './pages/FavoritesPage'
import { HomePage } from './pages/HomePage'
import { IngredientsPage } from './pages/IngredientsPage'
import { RecipesPage } from './pages/RecipesPage'
import { SettingsPage } from './pages/SettingsPage'
import { ShoppingPage } from './pages/ShoppingPage'
import type { AuthUser, PersistedAppData } from './types'

const navItems = [
  { to: '/', label: 'Početna', icon: Home },
  { to: '/ingredients', label: 'Namirnice', icon: Soup },
  { to: '/recipes', label: 'Recepti', icon: ListTodo },
  { to: '/shopping', label: 'Lista', icon: ShoppingCart },
  { to: '/favorites', label: 'Omiljeno', icon: Heart },
  { to: '/settings', label: 'Postavke', icon: Settings }
]

function Shell({ user, onLogout }: { user: AuthUser; onLogout: () => void }) {
  const { settings, setTheme } = useAppContext()

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 antialiased dark:bg-slate-950 dark:text-slate-100">
      <div className="mx-auto flex max-w-[1600px]">
        <aside className="hidden min-h-screen w-72 shrink-0 border-r border-slate-200 bg-white/90 p-5 backdrop-blur-xl dark:border-slate-700 dark:bg-slate-900/90 md:flex md:flex-col">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white shadow-soft">
              <ChefHat className="h-6 w-6" />
            </div>
            <div>
              <p className="text-xs font-medium uppercase tracking-[0.25em] text-emerald-600">IzFrižidera</p>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">Smart pantry</h2>
            </div>
          </div>

          <nav className="mt-8 space-y-2">
            {navItems.map(({ to, label, icon: Icon }) => (
              <NavLink
                key={to}
                to={to}
                className={({ isActive }) =>
                  `flex items-center gap-3 rounded-2xl px-3 py-3 text-base font-medium transition ${
                    isActive
                      ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-200'
                      : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-white'
                  }`
                }
              >
                <Icon className="h-5 w-5" />
                <span>{label}</span>
              </NavLink>
            ))}
          </nav>

          <div className="mt-auto rounded-[28px] bg-gradient-to-br from-slate-900 to-slate-700 p-4 text-white shadow-soft dark:from-slate-800 dark:to-slate-900">
            <p className="text-xs font-medium uppercase tracking-[0.2em] text-slate-300">Tema</p>
            <div className="mt-3 flex items-center gap-2">
              <button type="button" onClick={() => setTheme('light')} className={`inline-flex items-center gap-2 rounded-full border px-3 py-2 text-xs font-medium ${settings.theme === 'light' ? 'border-amber-400 bg-amber-400/20 text-amber-200' : 'border-slate-500 bg-slate-800 text-slate-200'}`}>
                <SunMedium className="h-4 w-4" /> Svijetli
              </button>
              <button type="button" onClick={() => setTheme('dark')} className={`inline-flex items-center gap-2 rounded-full border px-3 py-2 text-xs font-medium ${settings.theme === 'dark' ? 'border-indigo-400 bg-indigo-400/20 text-indigo-200' : 'border-slate-500 bg-slate-800 text-slate-200'}`}>
                <MoonStar className="h-4 w-4" /> Tamni
              </button>
            </div>
          </div>
        </aside>

        <main className="min-w-0 flex-1 p-3 md:p-6 xl:p-8">
          <div className="mb-4 flex items-center justify-end gap-3">
            <span className="max-w-[55vw] truncate text-sm font-medium text-slate-600 dark:text-slate-300">{user.name}</span>
            <button type="button" onClick={onLogout} aria-label="Odjavi se" title="Odjavi se" className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-600 transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700">
              <LogOut className="h-4 w-4" /> <span className="hidden sm:inline">Odjava</span>
            </button>
          </div>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/ingredients" element={<IngredientsPage />} />
            <Route path="/recipes" element={<RecipesPage />} />
            <Route path="/shopping" element={<ShoppingPage />} />
            <Route path="/favorites" element={<FavoritesPage />} />
            <Route path="/settings" element={<SettingsPage />} />
          </Routes>
        </main>
      </div>
      <BottomNav />
    </div>
  )
}

function App() {
  const [user, setUser] = useState<AuthUser | null>(null)
  const [initialData, setInitialData] = useState<PersistedAppData | null>(null)
  const [loading, setLoading] = useState(true)
  const [authError, setAuthError] = useState('')

  const acceptAuthenticatedUser = async (authenticatedUser: AuthUser) => {
    const result = await apiRequest<{ data: PersistedAppData | null }>('/api/data')
    setInitialData(result.data)
    setUser(authenticatedUser)
    setAuthError('')
    setLoading(false)
  }

  useEffect(() => {
    void apiRequest<{ user: AuthUser | null }>('/api/auth/me')
      .then(({ user: authenticatedUser }) => authenticatedUser ? acceptAuthenticatedUser(authenticatedUser) : setLoading(false))
      .catch((error: unknown) => {
        if (error instanceof TypeError) setAuthError('Lokalni poslužitelj nije dostupan. Pokrenite aplikaciju naredbom npm run dev.')
        setLoading(false)
      })
  }, [])

  const handleLogout = async () => {
    try {
      await apiRequest<{ ok: boolean }>('/api/auth/logout', { method: 'POST' })
    } finally {
      setUser(null)
      setInitialData(null)
    }
  }

  if (loading) {
    return <div className="flex min-h-screen items-center justify-center text-sm font-medium text-slate-600 dark:bg-slate-950 dark:text-slate-300">Učitavam tvoju kuhinju...</div>
  }

  if (!user) return <AuthPage onAuthenticated={acceptAuthenticatedUser} initialError={authError} />

  return (
    <AppProvider key={user.id} userId={user.id} initialData={initialData}>
      <BrowserRouter>
        <Shell user={user} onLogout={() => void handleLogout()} />
      </BrowserRouter>
    </AppProvider>
  )
}

export default App
