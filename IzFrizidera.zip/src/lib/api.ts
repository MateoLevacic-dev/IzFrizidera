interface ApiError {
  error?: string
}

export const apiRequest = async <T,>(path: string, options: RequestInit = {}): Promise<T> => {
  const response = await fetch(path, {
    ...options,
    credentials: 'include',
    headers: {
      ...(options.body ? { 'Content-Type': 'application/json' } : {}),
      ...options.headers
    }
  })

  const result = await response.json() as T & ApiError
  if (!response.ok) throw new Error(result.error || 'Zahtjev nije uspio.')
  return result
}