import { createContext } from 'react'
import type { ChatMessage, Ingredient, Recipe, RecipeMatch, ShoppingItem, UserSettings } from '../types'

export interface AppContextValue {
  ingredients: Ingredient[]
  shoppingList: ShoppingItem[]
  favoriteIds: string[]
  settings: UserSettings
  recipes: Recipe[]
  chatMessages: ChatMessage[]
  addIngredient: (ingredient: Omit<Ingredient, 'id'>) => void
  updateIngredient: (id: string, ingredient: Partial<Ingredient>) => void
  deleteIngredient: (id: string) => void
  addShoppingItem: (item: Omit<ShoppingItem, 'id'>) => void
  updateShoppingItem: (id: string, updates: Partial<ShoppingItem>) => void
  toggleShoppingItem: (id: string) => void
  deleteShoppingItem: (id: string) => void
  toggleFavorite: (recipeId: string) => void
  setSettings: (settings: UserSettings) => void
  setTheme: (theme: 'light' | 'dark') => void
  appendChatMessage: (message: ChatMessage) => void
  resetAppData: () => void
  getRecipeMatch: (recipe: Recipe) => RecipeMatch
  getExpiryStatus: (ingredient: Ingredient) => 'svježe' | 'uskoro istječe' | 'isteklo'
  addMissingIngredientsToShoppingList: (recipe: Recipe) => void
}

export const AppContext = createContext<AppContextValue | undefined>(undefined)