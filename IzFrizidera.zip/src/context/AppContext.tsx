import { useEffect, useState, type ReactNode } from 'react'
import { defaultSettings, defaultShoppingList, demoIngredients, demoRecipes } from '../data/demoData'
import { apiRequest } from '../lib/api'
import type { ChatMessage, Ingredient, PersistedAppData, Recipe, RecipeMatch, ShoppingItem, UserSettings } from '../types'
import { AppContext } from './appContextStore'
import type { AppContextValue } from './appContextStore'

const INGREDIENTS_KEY = 'izfrizidera.ingredients'
const SHOPPING_KEY = 'izfrizidera.shopping'
const FAVORITES_KEY = 'izfrizidera.favorites'
const SETTINGS_KEY = 'izfrizidera.settings'
const THEME_KEY = 'izfrizidera.theme'
const CHAT_KEY = 'izfrizidera.chat'

const readStoredValue = <T,>(key: string, fallback: T): T => {
  if (typeof window === 'undefined') return fallback

  const stored = window.localStorage.getItem(key)
  if (!stored) return fallback

  try {
    return JSON.parse(stored) as T
  } catch {
    return fallback
  }
}

const welcomeMessages: ChatMessage[] = [
  { id: 'welcome', sender: 'assistant', text: 'Zdravo! Ja sam Chef AI. Kako mogu pomoći s vašim namirnicama i receptima?' }
]

export const AppProvider = ({ children, userId, initialData }: { children: ReactNode; userId: string; initialData: PersistedAppData | null }) => {
  const [ingredients, setIngredients] = useState<Ingredient[]>(() => initialData?.ingredients ?? readStoredValue(`${INGREDIENTS_KEY}.${userId}`, demoIngredients))
  const [shoppingList, setShoppingList] = useState<ShoppingItem[]>(() => initialData?.shoppingList ?? readStoredValue(`${SHOPPING_KEY}.${userId}`, defaultShoppingList))
  const [favoriteIds, setFavoriteIds] = useState<string[]>(() => initialData?.favoriteIds ?? readStoredValue(`${FAVORITES_KEY}.${userId}`, ['r1', 'r7']))
  const [settings, setSettingsState] = useState<UserSettings>(() => initialData?.settings ?? readStoredValue(`${SETTINGS_KEY}.${userId}`, defaultSettings))
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>(() => initialData?.chatMessages ?? readStoredValue(`${CHAT_KEY}.${userId}`, welcomeMessages))

  useEffect(() => {
    const data: PersistedAppData = { ingredients, shoppingList, favoriteIds, settings, chatMessages }
    window.localStorage.setItem(`${INGREDIENTS_KEY}.${userId}`, JSON.stringify(ingredients))
    window.localStorage.setItem(`${SHOPPING_KEY}.${userId}`, JSON.stringify(shoppingList))
    window.localStorage.setItem(`${FAVORITES_KEY}.${userId}`, JSON.stringify(favoriteIds))
    window.localStorage.setItem(`${SETTINGS_KEY}.${userId}`, JSON.stringify(settings))
    window.localStorage.setItem(`${CHAT_KEY}.${userId}`, JSON.stringify(chatMessages))

    const timeout = window.setTimeout(() => {
      void apiRequest<{ ok: boolean }>('/api/data', { method: 'PUT', body: JSON.stringify(data) }).catch(() => undefined)
    }, 350)
    return () => window.clearTimeout(timeout)
  }, [userId, ingredients, shoppingList, favoriteIds, settings, chatMessages])

  useEffect(() => {
    const savedTheme = readStoredValue<'light' | 'dark'>(`${THEME_KEY}.${userId}`, settings.theme)
    document.documentElement.classList.toggle('dark', savedTheme === 'dark')
  }, [userId, settings.theme])

  const addIngredient = (ingredient: Omit<Ingredient, 'id'>) => {
    setIngredients((current) => [{ ...ingredient, id: crypto.randomUUID() }, ...current])
  }

  const updateIngredient = (id: string, ingredient: Partial<Ingredient>) => {
    setIngredients((current) => current.map((item) => (item.id === id ? { ...item, ...ingredient } : item)))
  }

  const deleteIngredient = (id: string) => {
    setIngredients((current) => current.filter((item) => item.id !== id))
  }

  const addShoppingItem = (item: Omit<ShoppingItem, 'id'>) => {
    setShoppingList((current) => [{ ...item, id: crypto.randomUUID() }, ...current])
  }

  const updateShoppingItem = (id: string, updates: Partial<ShoppingItem>) => {
    setShoppingList((current) => current.map((item) => (item.id === id ? { ...item, ...updates } : item)))
  }

  const toggleShoppingItem = (id: string) => {
    setShoppingList((current) => current.map((item) => (item.id === id ? { ...item, checked: !item.checked } : item)))
  }

  const deleteShoppingItem = (id: string) => {
    setShoppingList((current) => current.filter((item) => item.id !== id))
  }

  const toggleFavorite = (recipeId: string) => {
    setFavoriteIds((current) => (current.includes(recipeId) ? current.filter((item) => item !== recipeId) : [...current, recipeId]))
  }

  const setTheme = (theme: 'light' | 'dark') => {
    setSettingsState((current) => ({ ...current, theme }))
    document.documentElement.classList.toggle('dark', theme === 'dark')
    window.localStorage.setItem(`${THEME_KEY}.${userId}`, JSON.stringify(theme))
  }

  const appendChatMessage = (message: ChatMessage) => {
    setChatMessages((current) => [...current, message])
  }

  const setSettings = (nextSettings: UserSettings) => {
    setSettingsState(nextSettings)
  }

  const resetAppData = () => {
    setIngredients(demoIngredients)
    setShoppingList(defaultShoppingList)
    setFavoriteIds(['r1', 'r7'])
    setSettingsState(defaultSettings)
    setChatMessages(welcomeMessages)
    setTheme(defaultSettings.theme)
  }

  const buildExpiryStatus = (ingredient: Ingredient): 'svježe' | 'uskoro istječe' | 'isteklo' => {
    const now = new Date()
    const expiry = new Date(ingredient.expiryDate)
    const diff = (expiry.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)

    if (diff < 0) return 'isteklo'
    if (diff <= 3) return 'uskoro istječe'
    return 'svježe'
  }

  const getRecipeMatch = (recipe: Recipe): RecipeMatch => {
    const inventory = new Map(ingredients.map((ingredient) => [ingredient.name.toLowerCase(), ingredient]))
    const available: string[] = []
    const missing: string[] = []

    let matched = 0

    recipe.ingredients.forEach((ingredient) => {
      const ingredientName = ingredient.name.toLowerCase()
      const match = inventory.get(ingredientName)
      if (match) {
        available.push(ingredient.name)
        matched += 1
      } else {
        missing.push(ingredient.name)
      }
    })

    const score = recipe.ingredients.length === 0 ? 100 : Math.round((matched / recipe.ingredients.length) * 100)

    return {
      score,
      missing,
      available
    }
  }

  const addMissingIngredientsToShoppingList = (recipe: Recipe) => {
    const inventory = new Set(ingredients.map((ingredient) => ingredient.name.toLowerCase()))

    recipe.ingredients.forEach((ingredient) => {
      if (!inventory.has(ingredient.name.toLowerCase())) {
        setShoppingList((current) => {
          const exists = current.some((item) => item.name.toLowerCase() === ingredient.name.toLowerCase())
          if (exists) return current
          return [{ id: crypto.randomUUID(), name: ingredient.name, category: 'Ostalo', quantity: Number.parseFloat(ingredient.quantity) || 1, unit: ingredient.unit || 'kom', checked: false }, ...current]
        })
      }
    })
  }

  const contextValue: AppContextValue = {
      ingredients,
      shoppingList,
      favoriteIds,
      settings,
      recipes: demoRecipes,
      chatMessages,
      addIngredient,
      updateIngredient,
      deleteIngredient,
      addShoppingItem,
      updateShoppingItem,
      toggleShoppingItem,
      deleteShoppingItem,
      toggleFavorite,
      setSettings,
      setTheme,
      appendChatMessage,
      resetAppData,
      getRecipeMatch,
      getExpiryStatus: buildExpiryStatus,
      addMissingIngredientsToShoppingList
  }

  return <AppContext.Provider value={contextValue}>{children}</AppContext.Provider>
}

