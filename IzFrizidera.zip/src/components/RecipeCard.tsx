import { Clock3, Heart, Sparkles, TimerReset } from 'lucide-react'
import type { Recipe } from '../types'

interface RecipeCardProps {
  recipe: Recipe
  matchScore?: number
  missingCount?: number
  isFavorite?: boolean
  onToggleFavorite?: (recipeId: string) => void
  onAddMissing?: (recipe: Recipe) => void
}

export const RecipeCard = ({ recipe, matchScore, missingCount, isFavorite, onToggleFavorite, onAddMissing }: RecipeCardProps) => {
  const imageFallback = 'https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=900&q=80'

  return (
    <article className="group overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-xl dark:border-slate-700 dark:bg-slate-800">
      <div className="relative">
        <img
          src={recipe.image}
          alt={recipe.name}
          className="h-44 w-full object-cover transition duration-300 group-hover:scale-105"
          onError={(event) => {
            event.currentTarget.src = imageFallback
          }}
        />
        <button
          type="button"
          onClick={() => onToggleFavorite?.(recipe.id)}
          aria-label={isFavorite ? 'Ukloni omiljeno' : 'Dodaj u omiljeno'}
          className="absolute right-3 top-3 flex h-9 w-9 items-center justify-center rounded-full border border-white/80 bg-white/85 text-slate-700 shadow-sm backdrop-blur-sm transition hover:scale-105 dark:text-slate-900"
        >
          <Heart className={`h-4 w-4 ${isFavorite ? 'fill-red-500 text-red-500' : 'text-slate-700'}`} />
        </button>
      </div>

      <div className="space-y-3 p-4">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h3 className="line-clamp-2 text-lg font-semibold text-slate-900 dark:text-white">{recipe.name}</h3>
          </div>
          {typeof matchScore === 'number' && (
            <span className="rounded-full bg-emerald-100 px-2 py-1 text-xs font-semibold text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-200">
              {matchScore}%
            </span>
          )}
        </div>

        <p className="line-clamp-2 text-sm text-slate-600 dark:text-slate-300">{recipe.description}</p>

        <div className="flex flex-wrap gap-2 text-xs text-slate-600 dark:text-slate-300">
          <span className="inline-flex items-center gap-1 rounded-full bg-orange-50 px-2 py-1 text-orange-700 dark:bg-orange-950/30 dark:text-orange-200">
            <Clock3 className="h-3.5 w-3.5" /> {recipe.time} min
          </span>
          <span className="inline-flex items-center gap-1 rounded-full bg-indigo-50 px-2 py-1 text-indigo-700 dark:bg-indigo-950/30 dark:text-indigo-200">
            <TimerReset className="h-3.5 w-3.5" /> {recipe.difficulty}
          </span>
        </div>

        <div className="flex items-center justify-between gap-2 pt-1">
          <span className="inline-flex items-center gap-1 text-xs text-slate-500 dark:text-slate-400">
            <Sparkles className="h-3.5 w-3.5 text-amber-500" />
            {recipe.tags[0] ?? 'recept'}
          </span>
          <button
            type="button"
            onClick={() => onAddMissing?.(recipe)}
            disabled={missingCount === 0}
            className="rounded-full bg-slate-900 px-3 py-1.5 text-xs font-medium text-white transition hover:bg-slate-700 disabled:cursor-not-allowed disabled:bg-slate-200 disabled:text-slate-500 dark:bg-emerald-500 dark:text-slate-900 dark:hover:bg-emerald-400 dark:disabled:bg-slate-700 dark:disabled:text-slate-400"
          >
            {missingCount === 0 ? 'Sve imaš' : 'Dodaj što nedostaje'}
          </button>
        </div>
      </div>
    </article>
  )
}
