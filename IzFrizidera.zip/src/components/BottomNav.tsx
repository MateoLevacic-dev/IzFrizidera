import { Heart, Home, ListTodo, Settings, ShoppingCart, Soup } from 'lucide-react'
import { NavLink } from 'react-router-dom'

const navItems = [
  { to: '/', label: 'Početna', icon: Home },
  { to: '/ingredients', label: 'Namirnice', icon: Soup },
  { to: '/recipes', label: 'Recepti', icon: ListTodo },
  { to: '/shopping', label: 'Lista', icon: ShoppingCart },
  { to: '/favorites', label: 'Omiljeno', icon: Heart },
  { to: '/settings', label: 'Postavke', icon: Settings }
]

export const BottomNav = () => (
  <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-slate-200 bg-white/90 p-2 pb-[calc(env(safe-area-inset-bottom)+0.5rem)] backdrop-blur-xl dark:border-slate-700 dark:bg-slate-900/90 md:hidden">
    <div className="mx-auto grid max-w-md grid-cols-6 gap-1">
      {navItems.map(({ to, label, icon: Icon }) => (
        <NavLink
          key={to}
          to={to}
          className={({ isActive }) =>
            `flex flex-col items-center gap-1 rounded-2xl px-2 py-2 text-[10px] transition ${
              isActive ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-200' : 'text-slate-500 hover:text-slate-700 dark:text-slate-400'
            }`
          }
        >
          <Icon className="h-4 w-4" />
          <span>{label}</span>
        </NavLink>
      ))}
    </div>
  </nav>
)
