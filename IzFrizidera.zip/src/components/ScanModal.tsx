import { Camera, Check, Sparkles, X } from 'lucide-react'
import { useEffect, useRef, useState } from 'react'

interface ScanModalProps {
  isOpen: boolean
  onClose: () => void
  onConfirm: (items: string[]) => void
}

const detectedItems = ['Rajčica', 'Jaja', 'Sir', 'Mlijeko', 'Kruh']

export const ScanModal = ({ isOpen, onClose, onConfirm }: ScanModalProps) => {
  const [results, setResults] = useState<string[]>(detectedItems)
  const [loading, setLoading] = useState(false)
  const timeoutRef = useRef<number | null>(null)

  useEffect(() => {
    return () => {
      if (timeoutRef.current !== null) {
        window.clearTimeout(timeoutRef.current)
        timeoutRef.current = null
      }
    }
  }, [isOpen])

  if (!isOpen) return null

  const toggleItem = (item: string) => {
    setResults((current) => current.includes(item) ? current.filter((value) => value !== item) : [...current, item])
  }

  const handleAnalyze = () => {
    setLoading(true)
    timeoutRef.current = window.setTimeout(() => {
      timeoutRef.current = null
      setLoading(false)
      onConfirm(results)
    }, 1200)
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/55 p-4">
      <div className="w-full max-w-lg rounded-[28px] bg-white p-5 shadow-2xl dark:bg-slate-800">
        <div className="mb-4 flex items-center justify-between">
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-emerald-600">Skeniranje</p>
            <h3 className="mt-1 text-2xl font-bold text-slate-900 dark:text-white">Skeniraj namirnice</h3>
          </div>
          <button type="button" onClick={onClose} className="rounded-full p-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-700" aria-label="Zatvori modal">
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="rounded-[24px] border border-dashed border-slate-300 bg-slate-50 p-4 text-center dark:border-slate-600 dark:bg-slate-700/50">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-emerald-100 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-200">
            <Camera className="h-7 w-7" />
          </div>
          <p className="mt-3 text-lg font-semibold text-slate-800 dark:text-white">Analiziram fotografiju...</p>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">Demo fallback: ako AI servis nije konfiguriran, simuliram rezultat prepoznavanja.</p>
        </div>

        <div className="mt-5 space-y-3">
          <p className="text-sm font-medium uppercase tracking-[0.18em] text-slate-500">Prepoznato</p>
          <div className="flex flex-wrap gap-2">
            {detectedItems.map((item) => {
              const selected = results.includes(item)
              return (
                <button
                  key={item}
                  type="button"
                  onClick={() => toggleItem(item)}
                  className={`inline-flex items-center gap-2 rounded-full border px-3 py-2 text-sm font-medium transition ${
                    selected ? 'border-emerald-500 bg-emerald-50 text-emerald-700 dark:border-emerald-400 dark:bg-emerald-950/30 dark:text-emerald-200' : 'border-slate-200 bg-white text-slate-600 dark:border-slate-600 dark:bg-slate-700 dark:text-slate-200'
                  }`}
                >
                  {selected && <Check className="h-4 w-4" />} {item}
                </button>
              )
            })}
          </div>
        </div>

        <div className="mt-6 flex justify-end gap-3">
          <button type="button" onClick={onClose} className="rounded-full border border-slate-200 px-4 py-2.5 text-sm font-medium text-slate-600 hover:bg-slate-100 dark:border-slate-600 dark:text-slate-200 dark:hover:bg-slate-700">
            Odustani
          </button>
          <button type="button" onClick={handleAnalyze} disabled={loading} className="inline-flex items-center gap-2 rounded-full bg-emerald-500 px-4 py-2.5 text-sm font-semibold text-white hover:bg-emerald-600 disabled:cursor-not-allowed disabled:opacity-70">
            <Sparkles className="h-4 w-4" />
            {loading ? 'Analiziram...' : 'Potvrdi'}
          </button>
        </div>
      </div>
    </div>
  )
}
