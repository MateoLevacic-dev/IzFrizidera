import { useState, type FormEvent } from 'react'
import { CalendarDays, Plus, X } from 'lucide-react'
import type { Ingredient, IngredientCategory, StorageLocation } from '../types'

interface IngredientFormModalProps {
  isOpen: boolean
  onClose: () => void
  onSave: (ingredient: Omit<Ingredient, 'id'>) => void
  ingredient?: Ingredient
}

const categories: IngredientCategory[] = ['Povrće', 'Voće', 'Meso', 'Riba', 'Mliječni proizvodi', 'Jaja', 'Žitarice', 'Tjestenina', 'Konzervirano', 'Začini', 'Pića', 'Ostalo']
const locations: StorageLocation[] = ['Hladnjak', 'Zamrzivač', 'Smočnica']

const defaultIngredient = {
  name: '',
  category: 'Povrće' as IngredientCategory,
  quantity: 1,
  unit: 'kom',
  addedDate: new Date().toISOString().slice(0, 10),
  expiryDate: new Date(Date.now() + 86400000 * 5).toISOString().slice(0, 10),
  location: 'Hladnjak' as StorageLocation,
  image: ''
}

export const IngredientFormModal = ({ isOpen, onClose, onSave, ingredient }: IngredientFormModalProps) => {
  const [form, setForm] = useState({ ...defaultIngredient, ...(ingredient ?? {}) })
  const [error, setError] = useState('')

  if (!isOpen) return null

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (!form.name.trim()) {
      setError('Naziv namirnice je obavezan.')
      return
    }

    if (Number(form.quantity) <= 0) {
      setError('Količina mora biti veća od nule.')
      return
    }

    setError('')
    onSave({
      name: form.name.trim(),
      category: form.category,
      quantity: Number(form.quantity),
      unit: form.unit.trim() || 'kom',
      addedDate: form.addedDate,
      expiryDate: form.expiryDate,
      location: form.location,
      image: form.image || undefined
    })
    setForm({ ...defaultIngredient })
    onClose()
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 p-4">
      <div className="w-full max-w-lg rounded-[28px] bg-white p-5 shadow-2xl dark:bg-slate-800">
        <div className="mb-5 flex items-center justify-between">
          <div>
            <p className="text-sm font-medium uppercase tracking-[0.18em] text-emerald-600">Namirnica</p>
            <h3 className="mt-1 text-2xl font-bold text-slate-900 dark:text-white">{ingredient ? 'Uredi namirnicu' : 'Dodaj namirnicu'}</h3>
          </div>
          <button type="button" onClick={onClose} className="rounded-full p-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-700" aria-label="Zatvori">
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <label className="block">
            <span className="mb-1 block text-sm font-medium text-slate-700 dark:text-slate-200">Naziv</span>
            <input value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 outline-none ring-0 focus:border-emerald-500 dark:border-slate-600 dark:bg-slate-700 dark:text-white" placeholder="npr. jaje" />
          </label>

          <div className="grid gap-4 sm:grid-cols-2">
            <label className="block">
              <span className="mb-1 block text-sm font-medium text-slate-700 dark:text-slate-200">Kategorija</span>
              <select value={form.category} onChange={(event) => setForm({ ...form, category: event.target.value as IngredientCategory })} className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 outline-none focus:border-emerald-500 dark:border-slate-600 dark:bg-slate-700 dark:text-white">
                {categories.map((category) => (
                  <option key={category} value={category}>{category}</option>
                ))}
              </select>
            </label>

            <label className="block">
              <span className="mb-1 block text-sm font-medium text-slate-700 dark:text-slate-200">Lokacija</span>
              <select value={form.location} onChange={(event) => setForm({ ...form, location: event.target.value as StorageLocation })} className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 outline-none focus:border-emerald-500 dark:border-slate-600 dark:bg-slate-700 dark:text-white">
                {locations.map((location) => (
                  <option key={location} value={location}>{location}</option>
                ))}
              </select>
            </label>
          </div>

          <div className="grid gap-4 sm:grid-cols-3">
            <label className="block">
              <span className="mb-1 block text-sm font-medium text-slate-700 dark:text-slate-200">Količina</span>
              <input type="number" min="0" step="0.1" value={form.quantity} onChange={(event) => setForm({ ...form, quantity: Number(event.target.value) })} className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 outline-none focus:border-emerald-500 dark:border-slate-600 dark:bg-slate-700 dark:text-white" />
            </label>

            <label className="block">
              <span className="mb-1 block text-sm font-medium text-slate-700 dark:text-slate-200">Jedinica</span>
              <input value={form.unit} onChange={(event) => setForm({ ...form, unit: event.target.value })} className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 outline-none focus:border-emerald-500 dark:border-slate-600 dark:bg-slate-700 dark:text-white" placeholder="kom" />
            </label>

            <div className="flex items-end">
              <span className="inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-emerald-50 px-3 py-2.5 text-sm font-medium text-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-200">
                <CalendarDays className="h-4 w-4" /> {form.expiryDate}
              </span>
            </div>
          </div>

          <label className="block">
            <span className="mb-1 block text-sm font-medium text-slate-700 dark:text-slate-200">Rok trajanja</span>
            <input type="date" value={form.expiryDate} onChange={(event) => setForm({ ...form, expiryDate: event.target.value })} className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 outline-none focus:border-emerald-500 dark:border-slate-600 dark:bg-slate-700 dark:text-white" />
          </label>

          <label className="block">
            <span className="mb-1 block text-sm font-medium text-slate-700 dark:text-slate-200">URL fotografije (opcionalno)</span>
            <input value={form.image ?? ''} onChange={(event) => setForm({ ...form, image: event.target.value })} className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-3 py-2.5 outline-none focus:border-emerald-500 dark:border-slate-600 dark:bg-slate-700 dark:text-white" placeholder="https://..." />
          </label>

          {error && <p className="rounded-2xl bg-red-50 px-3 py-2 text-sm text-red-700 dark:bg-red-900/30 dark:text-red-200">{error}</p>}

          <div className="flex justify-end gap-3 pt-2">
            <button type="button" onClick={onClose} className="rounded-full border border-slate-200 px-4 py-2.5 text-sm font-medium text-slate-600 hover:bg-slate-100 dark:border-slate-600 dark:text-slate-200 dark:hover:bg-slate-700">
              Odustani
            </button>
            <button type="submit" className="inline-flex items-center gap-2 rounded-full bg-emerald-500 px-4 py-2.5 text-sm font-semibold text-white hover:bg-emerald-600">
              <Plus className="h-4 w-4" /> Spremi
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
