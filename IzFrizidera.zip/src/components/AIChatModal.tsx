import { Send, Sparkles, X } from 'lucide-react'
import { useState, type FormEvent } from 'react'
import type { ChatMessage } from '../types'

interface AIChatModalProps {
  isOpen: boolean
  onClose: () => void
  messages: ChatMessage[]
  onSend: (text: string) => void
}

export const AIChatModal = ({ isOpen, onClose, messages, onSend }: AIChatModalProps) => {
  const [input, setInput] = useState('')

  if (!isOpen) return null

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (!input.trim()) return
    onSend(input)
    setInput('')
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/55 p-4">
      <div className="flex h-[80vh] w-full max-w-2xl flex-col overflow-hidden rounded-[30px] bg-white shadow-2xl dark:bg-slate-800">
        <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4 dark:border-slate-700">
          <div className="flex items-center gap-2">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-amber-100 text-amber-600 dark:bg-amber-900/40 dark:text-amber-200">
              <Sparkles className="h-5 w-5" />
            </div>
            <div>
              <p className="text-sm font-medium uppercase tracking-[0.2em] text-amber-600">Demo AI</p>
              <h3 className="text-xl font-bold text-slate-900 dark:text-white">Chef AI</h3>
            </div>
          </div>
          <button type="button" onClick={onClose} className="rounded-full p-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-700" aria-label="Zatvori chat">
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="flex-1 space-y-3 overflow-y-auto bg-slate-50 px-4 py-4 dark:bg-slate-900/50">
          {messages.map((message) => (
            <div key={message.id} className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[80%] rounded-2xl px-3 py-2 text-sm ${message.sender === 'user' ? 'bg-emerald-500 text-white' : 'bg-white text-slate-700 dark:bg-slate-700 dark:text-slate-200'}`}>
                {message.text}
              </div>
            </div>
          ))}
        </div>

        <div className="border-t border-slate-200 p-4 dark:border-slate-700">
          <form onSubmit={handleSubmit} className="flex gap-2">
            <input
              value={input}
              onChange={(event) => setInput(event.target.value)}
              placeholder="Pitaj Chef AI..."
              className="flex-1 rounded-full border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none focus:border-emerald-500 dark:border-slate-600 dark:bg-slate-700 dark:text-white"
            />
            <button type="submit" aria-label="Pošalji poruku" className="inline-flex items-center justify-center rounded-full bg-emerald-500 p-3 text-white hover:bg-emerald-600">
              <Send className="h-4 w-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  )
}
