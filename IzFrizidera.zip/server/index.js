import { randomBytes, randomUUID, scrypt as scryptCallback, timingSafeEqual, createHash } from 'node:crypto'
import { promisify } from 'node:util'
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import express from 'express'
import initSqlJs from 'sql.js'

const scrypt = promisify(scryptCallback)
const root = dirname(fileURLToPath(import.meta.url))
const databasePath = join(root, '..', 'data', 'izfrizidera.sqlite')
const databaseDirectory = dirname(databasePath)
const port = Number(process.env.API_PORT) || 3001
const app = express()

app.disable('x-powered-by')
app.use(express.json({ limit: '1mb' }))

const SQL = await initSqlJs({
  locateFile: (file) => join(root, '..', 'node_modules', 'sql.js', 'dist', file)
})
const database = readFileSyncIfPresent(databasePath)
const db = database ? new SQL.Database(database) : new SQL.Database()

db.run('PRAGMA foreign_keys = ON')
db.run(`
  CREATE TABLE IF NOT EXISTS accounts (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    password_salt TEXT NOT NULL,
    created_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY,
    account_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
    expires_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS app_data (
    account_id TEXT PRIMARY KEY REFERENCES accounts(id) ON DELETE CASCADE,
    payload TEXT NOT NULL,
    updated_at INTEGER NOT NULL
  );
`)
saveDatabase()

function readFileSyncIfPresent(path) {
  try {
    return new Uint8Array(readFileSync(path))
  } catch (error) {
    if (error.code === 'ENOENT') return null
    throw error
  }
}

function saveDatabase() {
  mkdirSync(databaseDirectory, { recursive: true })
  writeFileSync(databasePath, Buffer.from(db.export()))
}

function queryOne(sql, values = []) {
  const statement = db.prepare(sql)
  try {
    statement.bind(values)
    return statement.step() ? statement.getAsObject() : null
  } finally {
    statement.free()
  }
}

function getCookie(request, name) {
  const cookies = request.headers.cookie?.split(';') ?? []
  const cookie = cookies.map((item) => item.trim()).find((item) => item.startsWith(`${name}=`))
  return cookie ? decodeURIComponent(cookie.slice(name.length + 1)) : ''
}

function hashToken(token) {
  return createHash('sha256').update(token).digest('hex')
}

function publicAccount(account) {
  return { id: account.id, name: account.name, email: account.email }
}

function setSessionCookie(response, token, remember) {
  const maxAge = remember ? '; Max-Age=2592000' : ''
  const secure = process.env.NODE_ENV === 'production' ? '; Secure' : ''
  response.setHeader('Set-Cookie', `izf_session=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax${maxAge}${secure}`)
}

function clearSessionCookie(response) {
  response.setHeader('Set-Cookie', 'izf_session=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0')
}

function createSession(response, accountId, remember) {
  const token = randomBytes(32).toString('base64url')
  const expiresAt = Date.now() + (remember ? 30 : 1) * 24 * 60 * 60 * 1000
  db.run('INSERT INTO sessions (token_hash, account_id, expires_at) VALUES (?, ?, ?)', [hashToken(token), accountId, expiresAt])
  saveDatabase()
  setSessionCookie(response, token, remember)
}

function requireAccount(request, response, next) {
  const token = getCookie(request, 'izf_session')
  if (!token) return response.status(401).json({ error: 'Prijava je istekla. Prijavite se ponovno.' })

  const session = queryOne(
    'SELECT accounts.id, accounts.name, accounts.email, sessions.token_hash FROM sessions JOIN accounts ON accounts.id = sessions.account_id WHERE sessions.token_hash = ? AND sessions.expires_at > ?',
    [hashToken(token), Date.now()]
  )

  if (!session) {
    clearSessionCookie(response)
    return response.status(401).json({ error: 'Prijava je istekla. Prijavite se ponovno.' })
  }

  request.account = session
  return next()
}

app.post('/api/auth/register', async (request, response, next) => {
  try {
    const name = typeof request.body.name === 'string' ? request.body.name.trim() : ''
    const email = typeof request.body.email === 'string' ? request.body.email.trim().toLowerCase() : ''
    const password = typeof request.body.password === 'string' ? request.body.password : ''
    const remember = request.body.remember === true

    if (name.length < 2 || name.length > 80) return response.status(400).json({ error: 'Ime mora imati od 2 do 80 znakova.' })
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) return response.status(400).json({ error: 'Unesite ispravnu e-mail adresu.' })
    if (password.length < 8 || password.length > 200) return response.status(400).json({ error: 'Lozinka mora imati najmanje 8 znakova.' })
    if (queryOne('SELECT id FROM accounts WHERE email = ?', [email])) return response.status(409).json({ error: 'Račun s ovom e-mail adresom već postoji.' })

    const id = randomUUID()
    const salt = randomBytes(16).toString('hex')
    const passwordHash = (await scrypt(password, salt, 64)).toString('hex')
    db.run('INSERT INTO accounts (id, name, email, password_hash, password_salt, created_at) VALUES (?, ?, ?, ?, ?, ?)', [id, name, email, passwordHash, salt, Date.now()])
    createSession(response, id, remember)
    return response.status(201).json({ user: { id, name, email } })
  } catch (error) {
    return next(error)
  }
})

app.post('/api/auth/login', async (request, response, next) => {
  try {
    const email = typeof request.body.email === 'string' ? request.body.email.trim().toLowerCase() : ''
    const password = typeof request.body.password === 'string' ? request.body.password : ''
    const remember = request.body.remember === true
    const account = queryOne('SELECT * FROM accounts WHERE email = ?', [email])

    if (!account || password.length > 200) return response.status(401).json({ error: 'E-mail ili lozinka nisu ispravni.' })
    const providedHash = await scrypt(password, account.password_salt, 64)
    const savedHash = Buffer.from(account.password_hash, 'hex')
    if (providedHash.length !== savedHash.length || !timingSafeEqual(providedHash, savedHash)) {
      return response.status(401).json({ error: 'E-mail ili lozinka nisu ispravni.' })
    }

    createSession(response, account.id, remember)
    return response.json({ user: publicAccount(account) })
  } catch (error) {
    return next(error)
  }
})

app.get('/api/auth/me', (request, response) => {
  const token = getCookie(request, 'izf_session')
  if (!token) return response.json({ user: null })

  const account = queryOne(
    'SELECT accounts.id, accounts.name, accounts.email FROM sessions JOIN accounts ON accounts.id = sessions.account_id WHERE sessions.token_hash = ? AND sessions.expires_at > ?',
    [hashToken(token), Date.now()]
  )
  if (!account) clearSessionCookie(response)
  return response.json({ user: account ? publicAccount(account) : null })
})

app.post('/api/auth/logout', (request, response) => {
  const token = getCookie(request, 'izf_session')
  if (token) {
    db.run('DELETE FROM sessions WHERE token_hash = ?', [hashToken(token)])
    saveDatabase()
  }
  clearSessionCookie(response)
  response.json({ ok: true })
})

app.get('/api/data', requireAccount, (request, response) => {
  const row = queryOne('SELECT payload FROM app_data WHERE account_id = ?', [request.account.id])
  response.json({ data: row ? JSON.parse(row.payload) : null })
})

app.put('/api/data', requireAccount, (request, response) => {
  const payload = JSON.stringify(request.body)
  if (payload.length > 1_000_000) return response.status(413).json({ error: 'Podaci su preveliki za spremanje.' })
  db.run(
    'INSERT INTO app_data (account_id, payload, updated_at) VALUES (?, ?, ?) ON CONFLICT(account_id) DO UPDATE SET payload = excluded.payload, updated_at = excluded.updated_at',
    [request.account.id, payload, Date.now()]
  )
  saveDatabase()
  response.json({ ok: true })
})

app.use((error, request, response, _next) => {
  console.error(error)
  response.status(500).json({ error: 'Došlo je do pogreške na poslužitelju.' })
})

app.listen(port, '127.0.0.1', () => {
  console.log(`IzFrižidera API radi na http://127.0.0.1:${port}`)
})